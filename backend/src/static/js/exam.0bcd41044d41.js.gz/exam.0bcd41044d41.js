// static/js/exam.js — FINAL VERSION (Sinkron dengan sistem terbaru)

const ExamApp = (() => {
  const API_BASE = "/api/exam/exams";

  /* --------------------------
      Helpers
  ---------------------------*/
  function xhrJson(url, opts = {}) {
    opts.headers = Object.assign(
      { "X-Requested-With": "XMLHttpRequest" },
      opts.headers || {}
    );

    // Jika body object → JSON
    if (opts.body && typeof opts.body === "object") {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(opts.body);
    }

    opts.credentials = "same-origin";

    return fetch(url, opts).then(async (res) => {
      const text = await res.text();
      let data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch (e) {
        data = text;
      }
      if (!res.ok) throw data;
      return data;
    });
  }

  function escapeHtml(v) {
    if (!v) return "";
    return String(v)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function formatDate(dt) {
    if (!dt) return "-";
    try {
      return new Date(dt).toLocaleString();
    } catch {
      return dt;
    }
  }

  /* --------------------------
      LIST PAGE
  ---------------------------*/
  async function loadExams(tbodySelector, alertSelector) {
    const tbody = document.querySelector(tbodySelector);
    const alertArea = document.querySelector(alertSelector);
    tbody.innerHTML = `<tr><td colspan="5">Memuat…</td></tr>`;

    try {
      const exams = await xhrJson(`${API_BASE}/`);
      if (!Array.isArray(exams) || exams.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5">Tidak ada ujian.</td></tr>`;
        return;
      }

      tbody.innerHTML = "";
      exams.forEach((ex) => {
        const tr = document.createElement("tr");

        tr.innerHTML = `
          <td>${escapeHtml(ex.title)}</td>
          <td>${escapeHtml(ex.description || "")}</td>
          <td>${ex.duration_minutes ? ex.duration_minutes + " menit" : "-"}</td>
          <td>${formatDate(ex.start_time)} — ${formatDate(ex.end_time)}</td>
          <td>
            <a href="/exams/${ex.id}/start/" class="btn btn-sm btn-primary">
              Detail / Mulai
            </a>
            
            ${
              ex.user_attempt
                ? `
                  <a href="/exams/${ex.id}/attempt/${ex.user_attempt}/result/" 
                     class="btn btn-sm btn-outline-secondary ms-1">
                    Hasil
                  </a>
                `
                : `<span class="text-muted small ms-2">Belum mengerjakan</span>`
            }
          </td>
        `;

        tbody.appendChild(tr);
      });
    } catch (err) {
      console.error(err);
      alertArea.innerHTML = `<div class="alert alert-danger">Gagal memuat ujian.</div>`;
      tbody.innerHTML = `<tr><td colspan="5">Terjadi error.</td></tr>`;
    }
  }

  /* --------------------------
      START PAGE
  ---------------------------*/
  async function initStartPage(examId) {
    try {
      const exam = await xhrJson(`${API_BASE}/${examId}/`);

      document.getElementById("exam-title").textContent = exam.title;
      document.getElementById("exam-desc").textContent = exam.description || "-";
      document.getElementById("exam-duration").textContent =
        exam.duration_minutes ? exam.duration_minutes + " menit" : "-";
      document.getElementById("exam-passing").textContent =
        exam.passing_grade ?? "-";

      document.getElementById("btn-start").onclick = async () => {
        document.getElementById("start-area").style.display = "none";
        document.getElementById("start-loading").style.display = "block";

        try {
          const data = await xhrJson(`${API_BASE}/${examId}/start/`, {
            method: "POST",
          });

          const ue = data.user_exam_id || data.user_exam || data.id;

          window.location.href = `/exams/${examId}/attempt/${ue}/`;
        } catch (err) {
          console.error(err);
          alert("Tidak bisa memulai ujian.");
          document.getElementById("start-area").style.display = "block";
          document.getElementById("start-loading").style.display = "none";
        }
      };
    } catch (err) {
      console.error(err);
      alert("Gagal memuat data ujian.");
    }
  }

  /* --------------------------
      RESULT PAGE
  ---------------------------*/
  async function initResultPage(examId, attemptId) {
    const box = document.getElementById("result-box");

    try {
      const data = await xhrJson(`${API_BASE}/${examId}/my-result/`);

      const examTitle = data.exam?.title || "Ujian";
      const hasPassing =
        data.passing_grade !== null && data.passing_grade > 0;
      const passed = hasPassing ? data.score >= data.passing_grade : null;

      box.innerHTML = `
        <div class="card p-4 shadow-sm">
          <h4 class="mb-3">${examTitle}</h4>

          <div class="mb-2"><strong>Score:</strong> ${data.score.toFixed(2)}</div>
          <div class="mb-2"><strong>Raw Score:</strong> ${data.raw_score}</div>

          ${
            hasPassing
              ? `
                <div class="mb-2"><strong>Passing Grade:</strong> ${data.passing_grade}</div>
                <span class="badge ${passed ? "bg-success" : "bg-danger"}">
                  ${passed ? "LULUS" : "TIDAK LULUS"}
                </span>
              `
              : ""
          }

          <div class="text-muted small mt-3">
            <div><strong>Mulai:</strong> ${data.start_time || "-"}</div>
            <div><strong>Selesai:</strong> ${data.end_time || "-"}</div>
            <div><strong>Status:</strong> ${data.status}</div>
            <div><strong>Attempt:</strong> ${data.attempt_number}</div>
          </div>
        </div>
      `;
    } catch (err) {
      console.error(err);
      box.innerHTML = `<div class="alert alert-danger">Gagal memuat hasil ujian.</div>`;
    }
  }

  /* --------------------------
      Public API
  ---------------------------*/
  return {
    initListPage: (tbodySel, alertSel) =>
      loadExams(tbodySel, alertSel),

    initStartPage,

    // Attempt page FULL handled by exam_attempt.js → tidak diperlukan di sini
    // initAttemptPage: ...

    initResultPage,
  };
})();
  